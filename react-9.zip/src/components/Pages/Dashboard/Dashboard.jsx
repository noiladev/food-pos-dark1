import React from 'react'
import  DTop from '../../Dashboard/DTop';
import './Dashboard.scss'

function Dashboard() {
  return (
    <div className='dashboard'>
      <DTop/>
    </div>  
  )
}

export default Dashboard
