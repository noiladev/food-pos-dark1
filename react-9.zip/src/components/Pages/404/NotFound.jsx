import React from 'react'
import './NotFound.scss'
function NotFound() {
  return (
    <div className='notfound'>
      <h2>404 page not found</h2>
      {/* <img src="https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.alamy.com%2Fglitch-error-404-computer-page-anaglyph-glitch-404-banner-error-layout-effect-screen-image401396923.html&psig=AOvVaw3J4JR70c2d16W9vZfYc_zz&ust=1704632930538000&source=images&cd=vfe&opi=89978449&ved=0CBMQjRxqFwoTCJC10vTqyIMDFQAAAAAdAAAAABAK" alt="" /> */}
    </div>
  )
}

export default NotFound
